package com.example.appschutz

import android.content.Context

object Guard {
    const val PASSWORD = "2017"
    private fun p(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun protectedPkgs(c: Context): Set<String> =
        p(c).getStringSet("pkgs", emptySet()) ?: emptySet()

    fun setProtected(c: Context, pkg: String, on: Boolean) {
        val s = protectedPkgs(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        p(c).edit().putStringSet("pkgs", s).apply()
    }

    fun allowFor(c: Context, ms: Long) =
        p(c).edit().putLong("until", System.currentTimeMillis() + ms).apply()

    fun isAllowed(c: Context) = System.currentTimeMillis() < p(c).getLong("until", 0L)
}
