package com.example.appschutz

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GuardService : AccessibilityService() {
    // Wörter, die auf Löschen/Deaktivieren hindeuten (DE + EN)
    private val danger = listOf(
        "uninstall", "deinstall", "delete", "löschen", "entfernen", "remove",
        "disable", "deaktiv", "force stop", "beenden", "stop", "turn off", "ausschalten"
    )
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (Guard.isAllowed(this)) return
        val now = System.currentTimeMillis()
        if (now - last < 1500) return
        val root = rootInActiveWindow ?: return
        val sb = StringBuilder()
        collect(root, sb, 0)
        val t = sb.toString().lowercase()
        if (danger.none { t.contains(it) }) return
        val labels = Guard.protectedPkgs(this).mapNotNull { label(it) } + "AppSchutz"
        if (labels.none { t.contains(it.lowercase()) }) return
        last = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, PasswordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun label(pkg: String): String? = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { null }

    private fun collect(n: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (n == null || depth > 30) return
        n.text?.let { out.append(it).append('\n') }
        n.contentDescription?.let { out.append(it).append('\n') }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
