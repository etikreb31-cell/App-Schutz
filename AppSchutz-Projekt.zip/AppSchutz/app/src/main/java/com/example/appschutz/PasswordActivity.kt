package com.example.appschutz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.*

class PasswordActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val openMain = intent.getBooleanExtra("open_main", false)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val input = EditText(this).apply {
            hint = "Passwort"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val ok = Button(this).apply { text = "OK" }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(TextView(this@PasswordActivity).apply { text = "Passwort eingeben"; textSize = 20f })
            addView(input)
            addView(ok)
        }
        setContentView(box)
        ok.setOnClickListener {
            if (input.text.toString() == Guard.PASSWORD) {
                Guard.allowFor(this, 60_000)
                if (openMain) startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                input.text.clear()
                Toast.makeText(this, "Falsches Passwort", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
