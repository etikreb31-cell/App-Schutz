package com.example.appschutz

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Guard.isAllowed(this)) {
            startActivity(Intent(this, PasswordActivity::class.java).putExtra("open_main", true))
            finish()
            return
        }
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launch, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val prot = Guard.protectedPkgs(this)
        val list = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_multiple_choice,
                apps.map { it.second }
            )
            apps.forEachIndexed { i, a -> setItemChecked(i, a.first in prot) }
            setOnItemClickListener { _, _, i, _ ->
                Guard.setProtected(this@MainActivity, apps[i].first, isItemChecked(i))
            }
        }
        val btn = Button(this).apply {
            text = "Schritt 1: Bedienungshilfe 'AppSchutz' einschalten"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(btn)
            addView(TextView(this@MainActivity).apply { text = "Schritt 2: Apps zum Schützen anhaken"; setPadding(24, 16, 24, 16) })
            addView(list)
        })
    }
}
